package com.agileoracles.leave_portal_app.controller;

import com.agileoracles.leave_portal_app.dto.ObjectUploadResult;
import com.agileoracles.leave_portal_app.exception.InvalidFileException;
import com.agileoracles.leave_portal_app.model.LeaveCategorizationResult;
import com.agileoracles.leave_portal_app.service.LeaveCategorizationService;
import com.agileoracles.leave_portal_app.service.OciObjectStorageService;
import org.springframework.http.MediaType;
import org.springframework.security.core.Authentication;
import org.springframework.security.oauth2.core.user.OAuth2User;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.time.Instant;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;

@RestController
@RequestMapping("/api/leave")
public class LeaveUploadController {

    private static final long MAX_FILE_SIZE = 5 * 1024 * 1024;

    private final LeaveCategorizationService categorizationService;
    private final OciObjectStorageService objectStorageService;

    public LeaveUploadController(
            LeaveCategorizationService categorizationService,
            OciObjectStorageService objectStorageService
    ) {
        this.categorizationService = categorizationService;
        this.objectStorageService = objectStorageService;
    }

    @PostMapping(
            value = "/upload",
            consumes = MediaType.MULTIPART_FORM_DATA_VALUE
    )
    public Map<String, Object> upload(
            @RequestParam("file") MultipartFile file,
            Authentication authentication
    ) throws IOException {

        validateFile(file);

        String fileContent = new String(
                file.getBytes(),
                StandardCharsets.UTF_8
        );

        LeaveCategorizationResult categorizationResult =
                categorizationService.categorize(fileContent);

        ObjectUploadResult uploadResult =
                objectStorageService.uploadFile(file);

        String authenticatedUser =
                getAuthenticatedUser(authentication);

        Map<String, Object> response =
                new LinkedHashMap<>();

        response.put(
                "authenticatedUser",
                authenticatedUser
        );

        response.put(
                "uploadedFileName",
                file.getOriginalFilename()
        );

        response.put(
                "leaveCategory",
                categorizationResult
                        .category()
                        .getDisplayName()
        );

        response.put(
                "matchedKeywords",
                categorizationResult.matchedKeywords()
        );

        response.put(
                "reason",
                categorizationResult.reason()
        );

        response.put(
                "uploadTimestamp",
                Instant.now()
        );

        response.put(
                "objectName",
                uploadResult.objectName()
        );

        response.put(
                "objectId",
                uploadResult.objectId()
        );

        response.put(
                "etag",
                uploadResult.etag()
        );

        return response;
    }

    private String getAuthenticatedUser(
            Authentication authentication
    ) {
        if (authentication == null
                || !authentication.isAuthenticated()) {

            throw new IllegalStateException(
                    "The user is not authenticated."
            );
        }

        String authenticatedUser =
                authentication.getName();

        if (authentication.getPrincipal()
                instanceof OAuth2User oauth2User) {

            String email =
                    oauth2User.getAttribute("email");

            if (email != null && !email.isBlank()) {
                authenticatedUser = email;
            }
        }

        return authenticatedUser;
    }

    private void validateFile(MultipartFile file) {

        if (file == null || file.isEmpty()) {
            throw new InvalidFileException(
                    "Please upload a non-empty file."
            );
        }

        String fileName =
                file.getOriginalFilename();

        if (fileName == null || fileName.isBlank()) {
            throw new InvalidFileException(
                    "The uploaded file must have a valid name."
            );
        }

        if (!fileName
                .toLowerCase(Locale.ROOT)
                .endsWith(".txt")) {

            throw new InvalidFileException(
                    "Unsupported file type. Only .txt files are allowed."
            );
        }

        String contentType =
                file.getContentType();

        if (contentType != null
                && !contentType.isBlank()
                && !contentType.equalsIgnoreCase("text/plain")
                && !contentType.equalsIgnoreCase(
                "application/octet-stream"
        )) {

            throw new InvalidFileException(
                    "The uploaded file must be a plain text file."
            );
        }

        if (file.getSize() > MAX_FILE_SIZE) {
            throw new InvalidFileException(
                    "The uploaded file exceeds the 5 MB limit."
            );
        }
    }
}